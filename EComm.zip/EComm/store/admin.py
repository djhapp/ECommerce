from django.contrib import admin
from .models.product import Product


class AdminProduct(admin.ModelAdmin):
    list_display = ['id', 'shape', 'size', 'location', 'price']

# Register your models here.
admin.site.register(Product, AdminProduct)